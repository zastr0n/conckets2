<section class="py-16 bg-white">
    <div class="bg-white max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-4xl font-black text-center text-black mb-12">Key Features</h2>
        <div class="container mx-auto mt-20">
            <div class="card-container relative flex flex-col items-center space-y-6">
              <div class="bg-urlcard bg-black shadow-lg rounded-md p-6 transform translate-y-0 rotate-0">
                </div>
              <div class="card bg-black shadow-lg rounded-md p-6 transform -translate-y-4 rotate-2">
                </div>
              <div class="card bg-black shadow-lg rounded-md p-6 transform -translate-y-8 rotate-4">
                </div>
              </div>
          </div>
    </div>
</section>