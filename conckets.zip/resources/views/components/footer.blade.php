<footer class="bg-black py-8">
    <div class="container mx-auto px-4 text-center text-white">
        <p>&copy; 2024 Soundwave! All rights reserved.</p>
        <div class="mt-4">
            <a href="#" class="text-gray-400 hover:text-white mx-2"><i class="fab fa-facebook"></i></a> 
            <a href="#" class="text-gray-400 hover:text-white mx-2"><i class="fab fa-twitter"></i></a> 
            <a href="#" class="text-gray-400 hover:text-white mx-2"><i class="fab fa-instagram"></i></a> 
            <a href="#" class="text-gray-400 hover:text-white mx-2"><i class="fab fa-linkedin"></i></a> 
        </div>
    </div>
</footer>
